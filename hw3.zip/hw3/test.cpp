#include<iostream>



using namespace std;


class Box {
public:
    // Default constructor
    Box() {}

    // Initialize a Box with equal dimensions (i.e. a cube)
    explicit Box(int i) : m_width(i), m_length(i), m_height(i) // member init list
    {}

    // Initialize a Box with custom dimensions
    Box(int width, int length, int height)
        : m_width(width), m_length(length), m_height(height)
    {}




    int Volume() {
        return m_width * m_length * m_height; 
    }

private:
    // Will have value of 0 when default constructor is called.
    // If we didn't zero-init here, default constructor would
    // leave them uninitialized with garbage values.
    int m_width{ 0 };
    int m_length{ 0 };
    int m_height{ 0 };
};




int main(int argc, char *argv[]){

    Box b{3,2,5}; // Calls Box()

    // cout<<b<<endl; 

    // Using uniform initialization (preferred):
    Box b2 {5}; // Calls Box(int)

    // cout<<b2<<endl;
    
    Box b3 {5, 8, 12}; // Calls Box(int, int, int)

    
    // Using function-style notation:
    Box b4(2, 4, 6); // Calls Box(int, int, int)

    cout<<b.Volume()<<endl;
    

    return 0;
}